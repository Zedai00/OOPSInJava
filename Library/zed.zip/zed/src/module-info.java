module zed.array {
    exports zed.array;
}
